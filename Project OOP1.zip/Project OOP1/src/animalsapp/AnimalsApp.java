/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animalsapp;


public class AnimalsApp {
public static void main(String[] args) {
        AnimalUI ui = new AnimalUI();
        ui.menu();
    }
}


    






