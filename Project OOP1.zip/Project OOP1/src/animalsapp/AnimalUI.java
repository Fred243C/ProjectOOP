/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalsapp;

import javax.swing.JOptionPane;

/**
 *
 * @author Alex
 */
public class AnimalUI {
    private final Animals[] animalList;

    public AnimalUI() {
        // Create an array of Animals
        animalList = new Animals[]{
                new SiberianTiger("Siberian Tiger", "Panthera tigris altaica", "Forest", "Russia", "Endangered", 500, 1),
                new BlackRhino("Black Rhino", "Diceros bicornis", "Grassland", "Africa", "Critically Endangered", 2500, 2),
                new SnowLeopard("Snow Leopard", "Panthera uncia", "Mountain", "Himalayas", "Vulnerable", 1000, 3)
        };
    }

    public void menu() {
        // Display menu options
        int ans = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Select an animal:\n"+ "1. Siberian Tiger\n" + "2. Black Rhino\n" + "3. Snow Leopard"));

     // Display information about the selected animal
        displayAnimalInfo(animalList[ans - 1]);
    }

    private void displayAnimalInfo(Animals animal) {
        // Display information about the selected animal
        JOptionPane.showMessageDialog(null,
                "Animal Name: " + animal.getAnimalName()  
                        + "\n" +
                        "Species: " + animal.getSpecies() 
                        + "\n" +
                        "Habitat: " + animal.getHabitat()
                        + "\n" +
                        "Location: " + animal.getLocation()
                        + "\n" +
                        "Status: " + animal.getStatus()
                        + "\n" +
                        "Population: " + animal.getPopulation()
                        + "\n" +
                        "ID: " + animal.getId());
    }
}
    

