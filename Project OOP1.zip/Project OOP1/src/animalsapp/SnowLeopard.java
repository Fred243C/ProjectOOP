/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalsapp;

/**
 *
 * @author Alex
 */
public class SnowLeopard extends Animals{

    public SnowLeopard(String animalName, String species, String habitat, String location, String status, int population, int id) {
        super(animalName, species, habitat, location, status, population, id);
    }

    @Override
    public double Charity() {
       
        return 0;
       
    }
}
